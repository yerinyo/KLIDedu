package swedu.exercise;
 
 
/**
 * ID : Hong-1002-EXEC
 * 기능 : 구구단 실행 
 * @author 최태의 
 *
 */
public class CalcGuguExec {
 
	public static void main(String[] args) throws Exception  {
		 
		System.out.println( "\n\n 100  ============ 구구단 결과보기  ==============" );
		
		CalcNumChild CNC = new CalcNumChild(); 
		
		int guguLevel = 9;
		
		String resultOutString = " "; // 문자열 결과값 
		
		resultOutString = CNC.doGuguDan(guguLevel);
		
		System.out.println( "\n\n 100  ============ 구구단 결과보기  ==============" + guguLevel + "단");
		
		System.out.println( "구구단 결과값= \n" + resultOutString );
		
	}
	// EOF main 
}
// EOF Class 