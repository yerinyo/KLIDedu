import java.util.Vector;

import org.apache.log4j.Logger;

import swbiz.team3;
import swbiz.team3DAO;
import swedu.util.DBConnection;

/**
 * ID : TEAM3
 * 기능 : 도서 조회 
 * @version : 1.0  
 * @author : TEAM3 
*/ 
public class Team3Test {
	
	public static void main(String[] args) {
		
		team3DAO	CUD	= new team3DAO(); 
		team3		CUT	= new team3(); 
		
		int	 bookId  = 3; 
		
		Logger logger = Logger.getLogger("TEAM3_LOG");

		System.out.println("================= 0. 순번 호출  ==============="); 
		 
		try {
			
			// 도서정보 가져오기 
			CUD = CUT.getBookSeq(DBConnection.LOCAL_CONNECT);
			
			if ( CUD != null ) {
				logger.info("순번 MAX 값 => " + CUD.bookseq);
			}
			else {
				logger.info("======= F10. Fail to getRecord ======== ");
			}
		 
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		
		System.out.println("================= 1. 단샘플 호출  ==============="); 
	 
		try {
			
			// 도서정보 가져오기 
			CUD = CUT.getRecord(bookId, DBConnection.LOCAL_CONNECT);
			
			if ( CUD != null ) {
				logger.info(CUD.toString());		
			}
			else {
				logger.info("======= F10. Fail to getRecord ======== ");
			}
		 
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		
		
		System.out.println("================= 2. 복수샘플 호출 (도서별)  ==============="); 
		 
		try {
 
			 /*도서명에 따라서 검색진행*/ 
			String bookStr = "%"; 
			
			int cnt = 0; 	// 검색 도서 갯수 
			int seq = 0;    // 순번 
			// 도서정보 벡터목록 
			Vector<team3DAO>	 cVec = new Vector<team3DAO>(); 
			
			// 도서정보 가져오기 (특정 도서명 ) 
			cVec = CUT.getRecordAll(bookStr, DBConnection.LOCAL_CONNECT);
		
			if ( cVec != null ) {
				
				cnt = cVec.size();
				
				logger.info( "도서 제목 검색 = " + bookStr + " => " + cnt );		
				
				// START F1 
				for ( int i = 0;i < cnt; i++ ) {
					
					seq = i + 1;
					
					// 목록에서 데이터 셑 가져오기 
					CUD = cVec.elementAt(i); 
					
					logger.info(seq + " --> " + CUD.toString() );		
					
				}
				// EOF F1 	
			}
			else {
				logger.info("======= F20. Fail to getRecordAll ======== ");
			}
		 
		} 
		catch (Exception e) {
			e.printStackTrace();
		} 
		 
	}
	// EOF main 
	
}
// EOF Class 
 